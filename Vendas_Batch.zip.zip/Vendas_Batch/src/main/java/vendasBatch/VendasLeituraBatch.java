package vendasBatch;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.batch.item.ItemReader;

import vendas.entidades.Vendas;

public class VendasLeituraBatch implements ItemReader<Vendas> {
	ArrayList<Vendas> listaVendas = new ArrayList<Vendas>();
	Iterator<Vendas> it;	
	

	@SuppressWarnings("unused")
	@Override
	public Vendas read() throws Exception {
		System.out.println("Processando read");
		Vendas vendas = null;
		if(it != null && it.hasNext()) {
			vendas = it.next();
		}else {
			vendas = null;
		}
		
		
		return null;
	}
	

}
