package vendasBatch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import vendas.entidades.Vendas;

@Configuration
@EnableBatchProcessing

public class BatchComfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Bean
	public VendasLeituraBatch readerEmail() {
		return new VendasLeituraBatch();
	}
	
	@Bean
	public  VendasProcessamentoBatch processorEmail() {
		return new VendasProcessamentoBatch();
	}
	
	@Bean
	public VendasEscritaBatch writerEmail() {
		return new VendasEscritaBatch();
	}
	
	
	
	@Bean
	public Job processJob() {
		return jobBuilderFactory.get("processJob")
				.incrementer(new RunIdIncrementer())
				.flow(orderStep1()).end().build();
	}

	@Bean
	public Step orderStep1() {
		return stepBuilderFactory.get("orderStep1").<Vendas, Vendas> chunk(1)
				.reader((ItemReader<? extends Vendas>) readerEmail()).processor((ItemProcessor<? super Vendas, ? extends Vendas>) processorEmail())
				.writer((ItemWriter<? super Vendas>) writerEmail()).build();
	}

	
	

}
