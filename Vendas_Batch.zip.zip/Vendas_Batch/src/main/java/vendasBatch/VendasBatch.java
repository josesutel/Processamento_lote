package vendasBatch;

import java.util.Collection;
import java.util.Date;

import vendas.entidades.Vendas;

public class VendasBatch {
	
     int cpf;
	 long numCartao;
	 Date dataCompra;
	 Collection<? extends Vendas> valorProduto;
	 String descricaoProduto;
	public String dataCompra() {
		
		
		return null;
	}


}
