package vendasBatch;

import java.util.Collection;
import java.util.Date;

import vendas.entidades.Vendas;

public class ProcessaVendas {
	String produto;
	Date dataVenda;
	String mesProcessamento;
	
	
	
	Collection<? extends Vendas> Valor;
	public Date mesProcessamento(int month) {
		Vendas vds = new Vendas();
		if(mesProcessamento(month) == dataVenda ) {
		 vds.getValorProduto() ;
		}
	
		return null;
	}
	
	
	

}
