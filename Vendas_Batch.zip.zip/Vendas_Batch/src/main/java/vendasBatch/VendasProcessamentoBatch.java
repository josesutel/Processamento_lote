package vendasBatch;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.batch.api.chunk.ItemProcessor;

import vendas.entidades.Vendas;

public class VendasProcessamentoBatch  implements ItemProcessor<VendasBatch, ProcessaVendas>{
	
	public ProcessaVendas process(VendasBatch item) throws Exception{
		System.out.println("Processando Vendas");
		
		ProcessaVendas processaVendas = new ProcessaVendas();
	    processaVendas.mesProcessamento = " 12";
		processaVendas.dataVenda = item.dataCompra;
		processaVendas.produto = item.descricaoProduto;
		processaVendas.Valor = item.valorProduto;
	    SimpleDateFormat sdformat = new SimpleDateFormat("dd-MM-yyyy");
	   
		 if(item.dataCompra ==  processaVendas.mesProcessamento(Calendar.MONTH)) { 
			ArrayList<Vendas> relatorio = new ArrayList<Vendas>();
			relatorio.addAll(processaVendas.Valor);
			System.out.println( "realtorio :" + processaVendas.Valor );
		 }	   
  
		 
		
		
		return processaVendas;
	}

	@Override
	public Object processItem(Object item) throws Exception {
	
		return null;
	}

	
 
//	public ProcessaVendas processa(Vendas item) throws Exception{
//		Select CrudRepository from  ;
//	}
//	
}
