package vendasBatch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.batch.api.chunk.ItemWriter;

public class VendasEscritaBatch implements ItemWriter<ProcessaVendas> {
	
	public void write (List<? extends ProcessaVendas> items) throws Exception{
	for(ProcessaVendas user : items) {
		escreveArquivo(user);
		System.out.println("escrevendo vendas");
	}
	}
	
	private void escreveArquivo(ProcessaVendas Vendas)throws IOException {
		File file = new File("Relatorio.txt");
		if(!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
		BufferedWriter bw = new BufferedWriter(fw);
		String texto = Vendas.produto + "-" + Vendas.Valor + "-" + Vendas.dataVenda + "\n";
		bw.write(texto);
		bw.close();
	}

	

	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void writeItems(List<Object> items) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public Serializable checkpointInfo() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void open(Serializable checkpoint) throws Exception {
		// TODO Auto-generated method stub
		
	}

	

	
	
}
