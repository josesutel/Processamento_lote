package vendas.repository;

import org.springframework.data.repository.CrudRepository;

import vendas.entidades.Vendas;

public interface VendasRepository extends
CrudRepository<Vendas, Long>{

	

}
