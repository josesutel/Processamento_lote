package vendas;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;


//@ComponentScan({"veriCartao.api","veriCartao.entidades","veriCartao.service","veriCartao.repository"})
@SpringBootApplication
public class StartServer {

	public static void main(String[] args) {
		// iniciacao do spring boot
		//SpringApplication.run(StartServer.class, args);
		SpringApplication app = new SpringApplication(StartServer.class);
		app.setDefaultProperties(Collections.singletonMap("server.port", "8084"));
		
		app.run(args);
		
	}

	
	@Bean
	public RestTemplate rest(RestTemplateBuilder builder) {
		RestTemplate restTemplate = builder.build();
		return restTemplate;
	}
	
	public static void teste() {
		
	}
}

