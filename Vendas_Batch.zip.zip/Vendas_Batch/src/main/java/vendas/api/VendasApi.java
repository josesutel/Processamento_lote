package vendas.api;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import vendas.entidades.Cartao;
import vendas.entidades.Clientes;
import vendas.entidades.Vendas;
import vendas.service.CartaoServiceImpl;
import vendas.service.ClientesServiceImpl;
import vendas.service.VendasService;

@RestController(value="API iclusão de vendas")
public class VendasApi {

	@Autowired
	private VendasService vendasService;
	@Autowired
	private ClientesServiceImpl clientesService;
	@Autowired
    private CartaoServiceImpl cartaoService;
	
	
	
	@RequestMapping(value = "/vendas", method = RequestMethod.GET , produces = "application/json")
	public List<Vendas> getList(){
		return vendasService.buscar();
		
	}
	
	@RequestMapping(value = "/vendas", method = RequestMethod.POST , produces = "application/json" )
	public ResponseEntity<String>salvarVendas(@RequestBody Vendas vendas)throws Exception{
		ResponseEntity<String> ret = null;
		try {
			vendasService.salvarVendas(vendas);
		    ret =  new ResponseEntity<>("venda salva com sucesso",HttpStatus.OK);
			
		}catch(Exception e) {
			ret = new ResponseEntity<>(e.getMessage(),HttpStatus.METHOD_NOT_ALLOWED);
	}
        return ret;
}
	@RequestMapping(value = "/vendas" ,method = RequestMethod.DELETE , produces= "application/json")
	public ResponseEntity<String>RemoverVendas(@RequestBody Vendas vendas)throws Exception{
		ResponseEntity<String> ret= null;
		try {
			vendasService.deletarVendas(vendas);
			
		}catch(Exception e) {
			ret = new ResponseEntity<>("Ocorreu um erro" , HttpStatus.METHOD_NOT_ALLOWED);
		}
		return ret;
	}
	@RequestMapping(value = "/vendas", method = RequestMethod.PUT , produces = "application/json")
	public ResponseEntity<String>AlterarVenda(@RequestBody Vendas vendas)throws Exception{
		ResponseEntity<String> ret = null;
		try {
			vendasService.AlterarVenda(vendas);
			ret = new ResponseEntity<>("Venda alterada com sucesso" , HttpStatus.OK);
		}catch(Exception e) {
			ret = new ResponseEntity<>(e.getMessage(),HttpStatus.METHOD_NOT_ALLOWED);
		}
		return ret;
	}
	 @RequestMapping(value = "/clientes", method = RequestMethod.GET,  produces="text/plain")	 
	 public String ClientesCadastrados() throws Exception{
		 StringBuffer message = new StringBuffer();
		 Clientes[] clientes =  clientesService.buscaClientes();
		 for(int i=0; i <  clientes.length; i++) {
			 Clientes r = clientes[i];
			 message.append(r.getCpf()).append("\n");
		 }
		 
		 return message.toString();
	 }
	 @RequestMapping(value = "/cartao", method = RequestMethod.GET,  produces="text/plain")	 
	 public String CartaoExiste() throws Exception{
		 StringBuffer message = new StringBuffer();
		 Cartao[] cartao =  cartaoService.buscaCartao();
		 for(int i=0; i <  cartao.length; i++) {
			 Cartao r = cartao[i];
			 message.append(r.getCpf()).append("\n");
		 }
		 
		 return message.toString();
	 }

	
//	@ApiOperation(value = "Salva uma venda")
//	@ApiResponses(value = {
//		    @ApiResponse(code = 200, message = "Salvo com sucesso"),			    
//		    @ApiResponse(code = 405, message = "Erro ao ao salvar"),
//	         })

}
