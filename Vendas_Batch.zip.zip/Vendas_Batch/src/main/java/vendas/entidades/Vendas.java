package vendas.entidades;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import vendasBatch.ProcessaVendas;





@Entity
@Table(name = "vendas")
public class Vendas {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name ="cpf")
	private int cpf;
	
	@Column(name ="numCartao")
	private long numCartao;
	
	@Column(name ="dataCompra")
	private Date dataCompra;
	 
	@Column(name ="valorProduto")
	private long valorProduto;
	
	@Column(name ="descricaoProduto")
	private String descricaoProduto;

	
	
	
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	public long getNumCartao() {
		return numCartao;
	}

	public void setNumCartao(long numCartao) {
		this.numCartao = numCartao;
	}

	public Date getDataCompra() {
		return dataCompra;
	}

	public void setDataCompra(Date dataCompra) {
		this.dataCompra = dataCompra;
	}

	public long getValorProduto() {
		return valorProduto;
	}

	public void setValorProduto(long valorProduto) {
		this.valorProduto = valorProduto;
	}

	public String getDescricaoProduto() {
		return descricaoProduto;
	}

	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}
	
	public ProcessaVendas process(Vendas item) throws Exception{
		return null;
	}
	
	
}




