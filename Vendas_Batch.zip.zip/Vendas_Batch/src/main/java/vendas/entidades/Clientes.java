package vendas.entidades;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
    "id",
    "nome",
    "cpf",
    "senha",
    "email"
})


public class Clientes {
	@JsonProperty("id")
    private String id;
    @JsonProperty("nome")
    private String nome;
    @JsonProperty("cpf")
    private int cpf;
    @JsonProperty("senha")
    private String senha;
    @JsonProperty("email")
    private String email;
    
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    @JsonProperty("id")
	public String getId() {
		return id;
	}
    @JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}
    @JsonProperty("nome")
	public String getNome() {
		return nome;
	}
    @JsonProperty("nome")
	public void setNome(String nome) {
		this.nome = nome;
	}
    @JsonProperty("cpf")
	public int getCpf() {
		return cpf;
	}
    @JsonProperty("cpf")
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
    @JsonProperty("senha")
	public String getSenha() {
		return senha;
	}
    @JsonProperty("senha")
	public void setSenha(String senha) {
		this.senha = senha;
	}
    @JsonProperty("email")
	public String getEmail() {
		return email;
	}
    @JsonProperty("email")
	public void setEmail(String email) {
		this.email = email;
	}

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
    
}
