package vendas.entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
    "id",
    "cpf",
    "bandeira",
    "numCartao",
    "vencimento"
})
public class Cartao {
	@JsonProperty("id")
	private long id;
	@JsonProperty("cpf")
	private long cpf;
	@JsonProperty("bandeira")
	private String bandeira;
	@JsonProperty ("numCartao")
	private int numCartao;
	@JsonProperty("vencimento")
	private long vencimento;
	
	@JsonProperty("id")
	public long getId() {
		return id;
	}@JsonProperty("id")
	public void setId(long id) {
		this.id = id;
	}@JsonProperty("cpf")
	public long getCpf() {
		return cpf;
	}@JsonProperty("cpf")
	public void setCpf(long cpf) {
		this.cpf = cpf;
	}@JsonProperty("bandeira")
	public String getBandeira() {
		return bandeira;
	}@JsonProperty("bandeira")
	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}@JsonProperty("numCartao")
	public int getNumCartao() {
		return numCartao;
	}@JsonProperty("numCartao")
	public void setNumCartao(int numCartao) {
		this.numCartao = numCartao;
	}@JsonProperty("vencimento")
	public long getVencimento() {
		return vencimento;
	}@JsonProperty("veencimento")
	public void setVencimento(long vencimento) {
		this.vencimento = vencimento;
	}

	
}




