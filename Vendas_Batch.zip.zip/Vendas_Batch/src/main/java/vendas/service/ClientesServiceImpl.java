package vendas.service;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import vendas.entidades.Clientes;


@Service
public class ClientesServiceImpl {
	
private String endereco = "https://localhost:8080/api/v1/clientes";
	
	@Autowired
	 private  RestTemplate restTemplate;
  
    
	
	public  Clientes[] buscaClientesCallBack() throws Exception {
		Clientes clienteFake =  new Clientes();
		clienteFake.setId("0");
		clienteFake.setNome("dados fake");
		clienteFake.setCpf(0);
		clienteFake.setSenha("###");
		clienteFake.setEmail("XXXX");
		Clientes[] ret = new Clientes[1];
		ret[0] = clienteFake;
		return ret;		
	}
	
	@HystrixCommand(fallbackMethod = "buscaClienteCallBack",
		    commandProperties = {
		            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000"),
	}) 
	public Clientes[] buscaClientes()  throws Exception{
		URI endPoint = URI.create(endereco);
		
		Clientes[] entity  = this.restTemplate.getForObject(endPoint, Clientes[].class);
		
		return entity;
	}
	
	 

}
