package vendas.service;

import java.util.List;

import org.springframework.stereotype.Service;

import vendas.entidades.Vendas;

@Service
public interface VendasService {
	
	
	
	 
		
	
	
	
	public List<Vendas> buscar();

	public static Vendas[] buscaCartaoCallBack() {
		// TODO Auto-generated method stub
		return null;
	}
	public void salvarVendas(vendas.entidades.Vendas vendas) throws Exception;

	public  void deletarVendas(Vendas vendas) throws Exception;

	public void AlterarVenda(Vendas vendas) throws Exception;
	
		
		
			
}
