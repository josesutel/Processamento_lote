package vendas.service;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import vendas.entidades.Cartao;
import vendas.entidades.Clientes;

@Service
public class CartaoServiceImpl {
private String endereco = "https://localhost:8082/api/v1/cartao";
	
	@Autowired
	 private  RestTemplate restTemplate;
  
    
	
	public  Cartao[] buscaCartaoCallBack() throws Exception {
		Cartao cartaoFake =  new Cartao();
		cartaoFake.setId(0);
		cartaoFake.setCpf(0);
		cartaoFake.setBandeira("fake");
		cartaoFake.setVencimento(0);
		Cartao[] ret = new Cartao[1];
		ret[0] = cartaoFake;
		return ret;		
	}
	
	@HystrixCommand(fallbackMethod = "buscaCartaoCallBack",
		    commandProperties = {
		            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000"),
	}) 
	public Cartao[] buscaCartao()  throws Exception{
		URI endPoint = URI.create(endereco);
		
		Cartao[] entity  = this.restTemplate.getForObject(endPoint, Cartao[].class);
		
		return entity;
	}
	
	

}
