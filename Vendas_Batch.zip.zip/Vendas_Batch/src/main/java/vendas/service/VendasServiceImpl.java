package vendas.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import vendas.entidades.Clientes;
import vendas.entidades.Vendas;
@Service
public class VendasServiceImpl implements VendasService{
	
	private String endPoint = "http://localhost:8080/cartao";
	@Autowired
	private RestTemplate restTemplate;
	// @Autowired 
	// private vendas.repository.VendasRepository repository;
	 @Autowired
	private  CrudRepository<Vendas,Long> repository ;
	@Autowired
	private CrudRepository<?, Long> clientesrepository;
	 
	 
	public Vendas[]  buscaCartaoCallBack(){
		Vendas cartaoFalso = new Vendas();
		cartaoFalso.setId(0);
		cartaoFalso.setCpf(000000);
		cartaoFalso.setNumCartao(000000);
		Vendas[] ret = new Vendas[1];
		ret [0]= cartaoFalso;
		
		return ret;
	}
	@HystrixCommand(fallbackMethod = "buscaCartaoCallBack",
		    commandProperties = {
		            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000"),
	}) 
	
	public Vendas[] buscaCartao() {
		URI uri = URI.create(endPoint);
		
		Vendas[] entity  = this.restTemplate.getForObject(uri, Vendas[].class);
		
		return entity;
	}
	@Override
	public void salvarVendas(Vendas vendas) throws Exception {
		Clientes cli = new Clientes();
		if(cli.getCpf()== 123456 && cli.getCpf()== 654123) {
		
		//if( clientesrepository.existsById(Integer.toUnsignedLong(vendas.getCpf()))== false) {
			throw new Exception("Cliente nao cadastrado");
		}
	
		repository.save(vendas);
	}
	@Override
	public List<Vendas> buscar() {
		ArrayList<Vendas> lista = new ArrayList<Vendas>();
		Iterable<Vendas> userIt = repository.findAll();
		userIt.forEach(u -> lista.add(u));
		return lista;
		
	}
	@Override
	public void deletarVendas(Vendas vendas) throws Exception {
		
		if(vendas.getId()!= vendas.getId()) {
			throw new Exception("Digite o numero de ID correto");
			
		}
		repository.delete(vendas);
	}
	@Override
	public void AlterarVenda(Vendas vendas) throws Exception {
		if(vendas.getCpf()!= vendas.getCpf()) {
			throw new Exception("NUmero do CPF incorreto");
		}
		 repository.save(vendas);
		
		
	}


	

}
